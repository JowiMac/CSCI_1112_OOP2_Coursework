/* John Macdonald, Nov 11, 2022
 * 
 * This code displays text, changes
 * colors and positioning from user
 * input.
 * 
 * */
package exercise16_1;

import javafx.application.*;
import javafx.geometry.*;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.scene.layout.*;
import javafx.scene.*;
import javafx.event.*;

public class Exercise16_01 extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Exercise16_01");
		
		BorderPane borderPane = new BorderPane();
		
		double WIDTH = 500;
		double HEIGHT = 100;
		
		
		//RadioButtons at the top of the BorderPane
		HBox rbPane = new HBox (50);
		rbPane.setPadding(new Insets(5,0,0,5));
		
		RadioButton rbRed = new RadioButton("Red");
		RadioButton rbYellow = new RadioButton("Yellow");
		RadioButton rbBlack = new RadioButton("Black");
		RadioButton rbOrange = new RadioButton("Orange");
		RadioButton rbGreen = new RadioButton("Green");
		
		rbPane.getChildren().addAll(rbRed, rbYellow, rbBlack, rbOrange, rbGreen);
		
		
		
		//Words on screen in middle of borderPane
		Pane words = new Pane();
		Text text = new Text(200, 25, "Programming is fun!");
		words.getChildren().add(text);
		
		
		//Text movement buttons on bottom of borderPane
		HBox move = new HBox (20);
		move.setPadding(new Insets(0, 0, 0, 200));
		
		Button left = new Button("<=");
		Button right = new Button("=>");
		move.getChildren().addAll(left, right);
		
		
		//positioning in borderPane
		borderPane.setTop(rbPane);
		
		borderPane.setCenter(words);

		borderPane.setBottom(move);
		

		
	//left and right buttons to position the text
		left.setOnAction(
				new EventHandler<ActionEvent>(){
					@Override
					public void handle(ActionEvent e) {
						text.setX(text.getX() - 15);
						if(text.getX() <= 0) {
							text.setX(0);
						}
					}
				});
		
		right.setOnAction(
				new EventHandler<ActionEvent>(){
					@Override
					public void handle(ActionEvent e) {
						text.setX(text.getX() + 15);
						if(text.getX() >= 390) {
							text.setX(390);
						}
					}
				});
		
		
	//Radio button color changing events
		rbRed.setOnAction(
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent c) {
						text.setFill(Color.RED);
						}
				});
		
		rbYellow.setOnAction(
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent c) {
						text.setFill(Color.YELLOW);
						}
				});
		
		rbBlack.setOnAction(
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent c) {
						text.setFill(Color.BLACK);
						}
				});
		
		rbOrange.setOnAction(
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent c) {
						text.setFill(Color.ORANGE);
						}
				});
		
		rbGreen.setOnAction(
				new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent c) {
						text.setFill(Color.GREEN);
						}
				});
		
		
		
		
		Scene scene = new Scene(borderPane, WIDTH, HEIGHT);

		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
	
	
	
}//Exercise16_01 class end
