/* John Macdonald, Nov 14 2022
 * 
 * This code counts down from
 * user entered time, in seconds,
 * and plays music when it
 * reaches zero
 * */

package exercise16_21;

import javafx.animation.*;
import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.geometry.*;
import javafx.event.*;
import javafx.scene.media.*;
import javafx.util.Duration;

public class Exercise16_21 extends Application{
	@Override
	public void start(Stage primaryStage) throws Exception{
		primaryStage.setTitle("Exercise 16_21");
	
		int WIDTH = 175;
		int HEIGHT = 25;


		TextField text = new TextField();
			text.setEditable(true);
			text.setAlignment(Pos.BASELINE_CENTER);
		
			Media sound = new Media("https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3");
			MediaPlayer soundPlay = new MediaPlayer(sound);
		
		StackPane pane = new StackPane();
			pane.getChildren().add(text);
			
			

		pane.setOnKeyPressed(e -> {

		if(e.getCode() == KeyCode.ENTER) {
		
		Integer sec = Integer.parseInt(text.getText());

		Timeline animation = new Timeline(
		
		new KeyFrame(Duration.seconds(1), d -> {
			String seconds = text.getText();
			Integer seco = Integer.parseInt(seconds);
			
			text.setText(seco.toString(seco - 1));
			
		if(Integer.parseInt(text.getText()) == 0) {
			
			soundPlay.play();
			System.out.println("hi");
		}
		
		}));
			
		animation.setCycleCount(sec);

		animation.play();
		
		
		
		}//if statement end
		
		
});//pane.setOnKeyPressed end
		
		
		
		Scene scene = new Scene(pane, WIDTH, HEIGHT);
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}//method start end
	
	
	public static void main(String[] args) {
		Application.launch(args);
	}//main method end

}//class Exercise16_21 end
