/* John Macdonald, Nov 30 2022
 * 
 * This code finds the greatest
 * common divisor among 2 numbers
 * specified by the user
 * This assignment uses recursion
 * */

package program18_3;

import java.util.Scanner;

public class Program18_3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter two numbers separated by a space: ");
		int m = input.nextInt();
		int n = input.nextInt();
		
		int o = 1000;
		
		System.out.print("The greatest common divisor is " + divisor(m, n, o));		
	
	} // main method end

	
	public static int divisor(int m, int n, int o) {
		if(m % o == 0 && n % o == 0) {
			return o;
		} // if end
		else {
			o--;
		return divisor(m, n, o);
		} // else end
	} // divisor method end

	
//Greatest common divisor method interpreted from assignment text
//This code is not functional if called from main method
//	public static int gcd(int m, int n) {
//		if(m % n == 0) {
//			return (n = gcd(m,n));
//		} //if end
//		else{
//			return (gcd(n, (m % n)));
//		}
//		
//	} //gcd method end

	
} //class Program18_3 end
