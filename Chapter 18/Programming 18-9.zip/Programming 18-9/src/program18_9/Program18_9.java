/* John Macdonald, Nov 30 2022
 * 
 * This code prints reverse
 * characters of a string
 * This assignment uses recursion
 * */

package program18_9;

import java.lang.*;
import java.util.Scanner;

public class Program18_9 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a string to be reversed ");
		String value = input.next();
				
		System.out.print("This is the reverse string ");
				reverseDisplay(value);
		
	} // main method end

	public static void reverseDisplay(String value) { // This cannot be changed

//	Simpler way to solve without recursion		
//		StringBuilder eulav = new StringBuilder(value);
//		
//		System.out.println("This is the reverse string " + eulav.reverse());
		
		StringBuilder reve = new StringBuilder(value);
		
		String newValue = "";
		
		if((value.length() - 1) == 0) {
			System.out.print(reve.charAt(0));
		} // if end
		
		else {
		System.out.print(reve.charAt(value.length() - 1));
		reve.deleteCharAt(value.length() - 1);
		
		for(int i = 0; i < value.length() - 1; i++) {
		newValue = newValue + reve.charAt(i);
		} // for loop end
		
		value = newValue;
		
		reverseDisplay(value);
		} // else end

	} // reverseDisplay method end
} // Program18_9 class end
