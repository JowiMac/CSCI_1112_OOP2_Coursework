/* John Macdonald
 * Dec 6, 2022
 * 
 * This code will sort the
 * Array in the void method
 * and later print it out in
 * the main method
 * 
 * */

package exercise19_09;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Exercise19_09 {
	public static void main(String[] args) {
	    ArrayList<Integer> list = new ArrayList<Integer>();
	    list.add(14);
	    list.add(24);
	    list.add(14);
	    list.add(42);
	    list.add(25);
	    
	    sort(list);
	    
	    ArrayList<Integer> newList = list;
	    
	    System.out.print(newList);
	  } // main method end
	
	@SuppressWarnings("unchecked")
	public static <E extends Comparable<E>> void sort(ArrayList<E> list) {
		
		ArrayList<E> listSort = list;
		Collections.sort(listSort);
//		list = listSort;      // using this code would make it shorter
		
// I could remove listSort ArrayList and the for loop and if statement after
		//this point to have the code sort just the list ArrayList
// The assignment required that I use the compareTo function		
		
		for(int i = 0; i < listSort.size() - 1; i++) {
			
			E ls = listSort.get(i);
			E l = list.get(i);
			
			if(l.compareTo(ls) > 0) {
				list.remove(i);
				list.add(i, ls);
			} // if statement end
			
		} // for loop end
			
	} // sort method end
	
} // class Exercise19_09 end
