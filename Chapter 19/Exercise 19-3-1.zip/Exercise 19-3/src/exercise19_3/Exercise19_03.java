/* John Macdonald
 * Dec 5, 2022
 * 
 * This code is testing
 * Exercise19_3
 * 
 * This code was given
 * to me to test
 * 
 * */

package exercise19_3;

import java.util.ArrayList;
import java.util.Collections;

public class Exercise19_03 {
	  public static void main(String[] args) {
	    ArrayList<Integer> list = new ArrayList<Integer>();
	    list.add(14);
	    list.add(24);
	    list.add(14);
	    list.add(42);
	    list.add(25);
	    
	    //added Exercise19_3 to removeDuplicates method
	    //added Collections.sort(list);
	    
	    Collections.sort(list);
	    
	    ArrayList<Integer> newList = Exercise19_3.removeDuplicates(list); 
	    
	    System.out.print(newList);
	  }
	}