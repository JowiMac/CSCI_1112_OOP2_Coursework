/* John Macdonald
 * Dec 5, 2022
 * 
 * This code removes
 * duplicates
 * 
 * */

package exercise19_3;

import java.util.ArrayList;

public class Exercise19_3 {
	
	public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list) {
		
		for(int i = 0; i < list.size() - 1; i++) {
			if((list.get(i)) == (list.get(i + 1))) {
			list.remove(i + 1);
			}
		}
		
		return list;
		
	}

}
