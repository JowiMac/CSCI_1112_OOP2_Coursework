/* John Macdonald, Nov 22 2022
 * 
 * I am modifying the code given to me
 */

package exercise17_07;

import java.io.*;

public class Exercise17_07 {
    public static void main(String[] args) throws FileNotFoundException {
        Loan loan1 = new Loan();
        Loan loan2 = new Loan(1.8, 10, 10000);
        
        try (
                ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Exercise17_07.dat", true));
        ) {
            output.writeObject(loan1);
            output.writeObject(loan2);
        }//try end 
        
        catch (IOException ex) {
            System.out.println("File could not be opened");
        }//try-catch end
        
        outputData(); //method call in main function
        
    }//main method end
    
    public static void outputData() {
    	
    	double total = 0;
    	
    	try (
    			ObjectInputStream input = new ObjectInputStream(new BufferedInputStream(new FileInputStream("Exercise17_07.dat")));)
    	{
    		while (true) {
    				Loan newNumbers = (Loan)(input.readObject());
    				total += newNumbers.getLoanAmount();
    		}
    			
    	}//try end
    	
    	catch (EOFException ex) {
    		System.out.println("This is the total of the loan objects " + total);
    	}//catch end
    	
    	
    	catch (Exception ex) {
    		System.out.println(ex);
    		
    	}//catch end
    	
    	
    	
    }//method OutputData end
    
    
}//class Exercise17_07 end
