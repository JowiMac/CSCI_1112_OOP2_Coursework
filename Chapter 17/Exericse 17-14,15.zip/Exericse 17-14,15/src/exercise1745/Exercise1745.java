/* John Macdonald, Nov 28 2022
 * 
 * This code encrypts and decrypts a file
 * */

package exercise1745;

import java.io.*;

public class Exercise1745 {
	public static void main(String[] args) throws IOException {
		
		
//encrypting
		
		try( 
				FileOutputStream output = new FileOutputStream("Exercise1745.dat");
			){
			for(int i = 0; i < 12; i++) {
				output.write(i + 5);
				
					
				}//for loop end
			}//try end
		
		
		
		
//decrypting
		
		try(
				FileInputStream input = new FileInputStream("Exercise1745.dat");
			){
			int value;
				while ((value = input.read()) != -1) {
				
					System.out.print((value - 5) + " ");
					
				}//while loop end
			
		}//try end

		
	}//main method end
}//class end
