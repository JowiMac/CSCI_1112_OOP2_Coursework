/*John Macdonald, Nov 18 2022
 * 
 * This program creates a new
 * text file and writes 100
 * random integers to it.
 * */

package exercise17_1;

import java.io.*;

public class Exercise17_1 {
	
	public static void main(String[] args) {
		try {
				FileOutputStream output = new FileOutputStream("Exercise17_01.txt");
			
				for (int j = 0; j < 100; j++) {
				
					int k = ((int)(Math.random() * 100));
								
					output.write(k);
				
				}//for loop end
			
			}//try end
		
		catch (IOException ex) {
			ex.printStackTrace();
			
		}//try-catch end
		
		System.out.println();

		try {
				FileInputStream input = new FileInputStream("Exercise17_01.txt");
			
			
				int value;
			
				for(int o = 0; o < 1000; o++) {
					
					if ((value = input.read()) == -1) {
						break;
					}
				
					System.out.print(value + " ");
				
					if (o % 10 == 9) {
						System.out.println();
					}//if statement end
			
				}//for loop end
			
			}//try end	
		
		catch(IOException ex) {
			ex.printStackTrace();
		}//try-catch end
		
	}//main method end
	
}//class Exercise17_1 end
