/*John Macdonald, Nov 18 2022
 * 
 * This program creates a new
 * text file and writes 100
 * random integers to it.
 * */



package exercise17_3;

import java.io.*;

public class Exercise17_3 {
	
	public static void main(String[] args) {
		Exercise17_3();
		readInput();
	}//main method end
		
	public static void Exercise17_3() {
		
		try {
			
			DataOutputStream write = new DataOutputStream(new FileOutputStream("Exercise17_03.dat"));
			
			System.out.println("Letters \"k\" written to document");
			
				for (int j = 0; j < 100; j++) {
				
					int k = ((int)(Math.random() * 100));
								
					write.writeInt(k);
					
					System.out.print("k = " + k + ", ");
					
					if(j % 5 == 4) {
						System.out.println();
					}
				
					}//for loop end
				
			}//try end
		
		catch (IOException ex) {
			ex.printStackTrace();
			
		}//try-catch end
		
		System.out.println();
	}//Exercise17_3 method end
		
	public static void readInput() {
		
		System.out.println("Numbers read from document");
		
		int total = 0;
		
		try {
			
			DataInputStream read = new DataInputStream(new FileInputStream("Exercise17_03.dat"));
			
				int value;

				for(int o = 0; o < 1000; o++) {
//					o < 100 and there was no other code additions
					
//					additions listed here
//					if(read.read() == -1) {
//						break;
//					}
					
					value = read.readInt();
					
					System.out.print(value + " ");
					
					total = (total + value);

					if (o % 10 == 9) {
						System.out.println("total = " + total);
					}//if statement end
			
				}//for loop end
			
				System.out.println();
				System.out.print("This is the total of all the numbers " + total);
				
			}//try end	
		
		catch(EOFException ex) {
			System.out.println();
			System.out.println("Total calculated");
			System.out.print("This is the total of all the numbers " + total);
			}
		
		catch(IOException ex) {
			ex.printStackTrace();
			
		}//try-catch end
		
	}//readInput method end
	
}//class Exercise17_1 end
