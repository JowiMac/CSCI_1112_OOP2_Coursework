/*John Macdonald, October 18, 2022
 * 
 * This program determines probability of two different objects
 */
package project;

import java.lang.*;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class Probability {
	
	//Data Fields
	
	//Array for defining dice and card numbers
	int[] dice = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
			11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
	
	int[] dieChosen;// this array was modified to display the chosen die or card
	
	//Card suits
	String Hearts = "Hearts";
	String Spades = "Spades";
	String Diamonds = "Diamonds";
	String Clubs = "Clubs";
	
	int user = 0;// user input
	int iterative = 0;// used to remove 1 card from the deck when comparing two cards from same deck
	int modResult = 0;// used to further define user input for the chosen object
	double max = 0.0;// stores the max number that a die can make
	int roll = 0;// stores random number
	int number = 0;// a random number generated for object chosen
	int cardType = 0;//used to determine the suit of the card	
	double chance = 0.0;// stores the percent chance of being rolled or drawn when passed to method getProbability()

	
	
	//Constructors
	Probability(){	
	}
	
	Probability(int user){	
	}
	
	
	//Methods
	
	//This method received the newUser variable and converted it to user for it to work in this file
	int getUserInput(int newUser) {
		user = newUser;
		return user;
	}//getUserInput end
	
	//This method was run in case the user wanted to compare two cards
	int getIterate(int iterate) {
		iterative = iterate;
		return iterative;
	}//getIterate end
	
	//This method input user input to create the max(labeled as modResult) of a die or card
	int setUserInput(int user) {
		if(user <= 6) {
			modResult = user * 2;
			return modResult;
		}
		else if (user == 7) {
			modResult = 20;
			return modResult;
		}
		else {
			modResult = 13;
			return modResult;
		}
	}//setUserInput method end
	
	
	//This method converts modResult into max and if user chose a card the max would equal 52
	double getMax(int modResult) {
		max = modResult;
		if (modResult == 13) {
			max = modResult * 4;
			return max;
		}
		else
			return max;
	}//getMax method end
	
	//This method set the dieChosen array to the die or card the user chose
	int[] setDice(int modResult) {
		dieChosen = new int[(modResult)];
		for (int i = 0; i < modResult; i++) {
			dieChosen[i] = dice[i];
		}
		return dieChosen;	
	}//setDice method end

	
//this method got a random die number and assigned it to roll variable
	int getDieNumber(int[] dieChosen) {
		number = (int)(Math.random() * dieChosen.length);
		roll = dieChosen[number];
		return roll;
	}//getDieNumber end
	
//this method is for displaying distinct cards like royals and aces
	String royals (int number) {
	if (number == 1)
		return "Ace";
	if (number > 1 && number < 11) {
		String cardNum = String.valueOf(number);
		return cardNum;
	}
	else if(number == 11) {
		return "Jack";}
	else if (number == 12) {
		return "Queen";}
	else 
		return "King";
	}//method royals end
	
// this method assigned a random card suit number to a card
	int getCardType() {
		int random = (int)((Math.random() * 4));
		cardType = random;
		return cardType;
	}//getCardType end
	
// this method took the card suit number and gave it a name
	String getCardSuit() {
		if(cardType == 0) {
		return Hearts;}
		
		else if(cardType == 1) {
		return Spades;}
		
		else if(cardType == 2) {
		return Diamonds;}
		
		else {
			return Clubs;}
	}//getCardSuit end
	
//This method returned the percent chance of two comparative objects
	double getProbability() {
		chance = (1 / max);
			if (max == 52 && iterative == 1) {
				max = 51;
				chance = (1 / max);
			}
		return chance;
	}//getProbability end
	
	
	
	
	
	
}//Probability end
