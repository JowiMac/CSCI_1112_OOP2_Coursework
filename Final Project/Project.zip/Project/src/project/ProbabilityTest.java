/* John Macdonald, October 18, 2022
 * 
 * This program determines probability of two different objects
 * 
 * 
 * Additional notes for me when coding. to be deleted before completion
 * 
 
 * -"Thank you for trying out my probability calculator" will print in the
 * 		terminal when ran. I dont know whether to input it in the textArea,
 * 			leave it to make sure that it still runs in the terminal without
 * 					issue or to omit it entirely.
 */


package project;

import java.util.ArrayList;
import java.util.Scanner;

import javafx.application.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.event.*;

public class ProbabilityTest extends Application {
	public static void main(String[] args) {
		
		launch(args);
		
	}//Method main end

	@Override
	public void start(Stage primaryStage) throws Exception {
		Pane pane = new Pane();
		
		Scene scene = new Scene(pane , 518, 550);
		
		primaryStage.setTitle("Probability Calculator");
		primaryStage.setScene(scene);
		primaryStage.show();
		
		HBox comparator1pane = new HBox(25);
		
		HBox comparator2pane = new HBox(25);
		
		RadioButton d2 = new RadioButton("d2");       //remember to re-add the character d
		RadioButton d4 = new RadioButton("d4");
		RadioButton d6 = new RadioButton("d6");
		RadioButton d8 = new RadioButton("d8");
		RadioButton d10 = new RadioButton("d10");
		RadioButton d12 = new RadioButton("d12");
		RadioButton d20 = new RadioButton("d20");
		RadioButton c52 = new RadioButton("52c");
		
		RadioButton d2v2 = new RadioButton("d2");
		RadioButton d4v2 = new RadioButton("d4");
		RadioButton d6v2 = new RadioButton("d6");
		RadioButton d8v2 = new RadioButton("d8");
		RadioButton d10v2 = new RadioButton("d10");
		RadioButton d12v2 = new RadioButton("d12");
		RadioButton d20v2 = new RadioButton("d20");
		RadioButton c52v2 = new RadioButton("52c");
		
		
		ToggleGroup group = new ToggleGroup();
		ToggleGroup group2 = new ToggleGroup();
		
//first probability object to compare		
		d2.setToggleGroup(group);
		d4.setToggleGroup(group);
		d6.setToggleGroup(group);
		d8.setToggleGroup(group);
		d10.setToggleGroup(group);
		d12.setToggleGroup(group);
		d20.setToggleGroup(group);
		c52.setToggleGroup(group);
		
		
	//To allow this to work with the old code I am reverting these to equal newUser	variable
		d2.setId("1");		// would prefer to have this at 2
		d4.setId("2");		// would prefer to have this at 4
		d6.setId("3");		// would prefer to have this at 6
		d8.setId("4");		// would prefer to have this at 8
		d10.setId("5");		// would prefer to have this at 10
		d12.setId("6");		// would prefer to have this at 12
		d20.setId("7");		// would prefer to have this at 20
		c52.setId("8");		// would prefer to have this at 52
		
//second probability object to compare
		d2v2.setToggleGroup(group2);
		d4v2.setToggleGroup(group2);
		d6v2.setToggleGroup(group2);
		d8v2.setToggleGroup(group2);
		d10v2.setToggleGroup(group2);
		d12v2.setToggleGroup(group2);
		d20v2.setToggleGroup(group2);
		c52v2.setToggleGroup(group2);
		
		d2v2.setId("1");		// would prefer to have this at 2
		d4v2.setId("2");		// would prefer to have this at 4
		d6v2.setId("3");		// would prefer to have this at 6
		d8v2.setId("4");		// would prefer to have this at 8
		d10v2.setId("5");		// would prefer to have this at 10
		d12v2.setId("6");		// would prefer to have this at 12
		d20v2.setId("7");		// would prefer to have this at 20
		c52v2.setId("8");		// would prefer to have this at 51
		
		comparator1pane.getChildren().addAll(d2, d4, d6, d8, d10, d12, d20, c52);
		comparator1pane.setLayoutX(0);
		comparator1pane.setLayoutY(35);
		
		comparator2pane.getChildren().addAll(d2v2, d4v2, d6v2, d8v2, d10v2, d12v2, d20v2, c52v2);
		comparator2pane.setLayoutX(0);
		comparator2pane.setLayoutY(95);
		
		//button
		Button calculate = new Button("Calculate");
		calculate.setLayoutX(225);
		calculate.setLayoutY(130);		
		
		
		Text text1 = new Text(160, 20, "Choose the first probability object");
		Text text2 = new Text(125, 80, "Choose the second probability object to compare");
		

		
		TextArea Results = new TextArea();
		Results.setWrapText(true);
		Results.setEditable(false);
		
		ScrollPane scrollPane = new ScrollPane(Results);
		scrollPane.setLayoutX(0);
		scrollPane.setLayoutY(175);
		
		pane.getChildren().addAll(comparator1pane, calculate, comparator2pane, text1, text2, scrollPane);
		
	
		
		//Calculate button action
		calculate.setOnAction(c -> {
			

			String textIn = "Here are your results\n";
			String textIn1 = "";
			String textIn2 = "";
			
			String textFinal = "";

			try {
			
			Toggle identify1 = group.getSelectedToggle();
			int input1 = Integer.valueOf(((Node) identify1).getId());
			
			Toggle identify2 = group2.getSelectedToggle();
			int input2 = Integer.valueOf(((Node) identify2).getId());
			
			
	//added and modified old code start
			
			int[] n = new int[2];// used to store both numbers that are rolled or drawn
			int[] g = new int[2];// used to store user inputs
			
			
			int newUserIn = 0;// user input
			int newUser = 0;// this is passed to most methods
			int totalDice = 0;// this equals the max of both dice
			int totalRoll = 0;// this equals the max of dice rolled
			int cardsComp = 0;// this is used for comparing two cards
			double times = 0;// this counts the number of times a number can be rolled on two dice 
			double totalPoss = 0.0;// this is used to calculate the total possibility of two dice
			double percentage = 0.0;// this is used to calculate the percentage (times / totalDice)
			
			ArrayList<Object> list = new ArrayList<>();// This stored Obj and Obj2, which are Probability and Probability2 respectively
			
			//intro

			for (int i = 0; i < 1; i++) {
				
		//First comparable object
				
			//Saving input and storing values
			newUserIn = input1;
			newUser = newUserIn;
			g[0] = newUser;
			n[1] = 21;
			
			if (g[0] == 8) {
				cardsComp = 1;
			}
			
			//Create first object
				Probability Probability = new Probability();
				Probability.getDieNumber(
						Probability.setDice(
							Probability.setUserInput(
								Probability.getUserInput(newUser))));
				
				Probability.getMax(Probability.setUserInput(Probability.getUserInput(newUser)));
				Probability.getCardType();
				Probability.getCardSuit();
					list.add(Probability);
					n[0] = Probability.roll;
					
				

	//Second object to compare
				
			//Saving input and storing values
				newUserIn = input2;
				newUser = newUserIn;
				g[1] = newUser;
			
			
		//Create second object
			Probability Probability2 = new Probability();
			Probability2.getDieNumber(
					Probability2.setDice(
						Probability2.setUserInput(
							Probability2.getUserInput(newUser))));
				
				Probability2.getMax(Probability2.setUserInput(Probability2.getUserInput(newUser)));
				Probability2.getIterate(cardsComp);
				list.add(Probability2);
				n[1] = Probability2.roll;
				
			//redo randomizer if the card from the second object equals the card from the first object
				if (newUser == 8 && n[0] == n[1] && Probability2.cardType == Probability.cardType) {
					Probability2.getDieNumber(
						Probability2.setDice(
							Probability2.setUserInput(
								Probability2.getUserInput(newUser))));
					
					Probability.getMax(Probability.setUserInput(Probability.getUserInput(newUser)));
					Probability2.getIterate(cardsComp);
					Probability2.getCardType();
					Probability2.getCardSuit();
						n[1] = Probability2.roll;
					}//else if end
				
			}//for loop end
		
		//Storing objects into the array
			Probability Obj = (Probability)list.get(0);
			Probability Obj2 = (Probability)list.get(1);

			

			/* This code was used for testing purposes
			 *  
			System.out.println(Obj2.iterative);

			System.out.println("\nThese are user inputs " + g[0] + " " + g[1]);
			System.out.println("These are number outcomes " + n[0] + " " + n[1]);
			
			if(g[0] == 8 || g[1] == 8) {
			System.out.println("These are the card types " + Obj.cardType + " " + Obj2.cardType);
			}
			*/
			
		//compare display code
			
			//dice comparing
			for(int r = 0; r < 2; r++) {
				if(0 < g[r] && g[r] < 8) {
					if (r == 0) {
					newUser = g[r];
					textIn1 = "You rolled a d" + (Obj.dieChosen.length) + " and got a " + (Obj.roll) + "\n";
					textIn = textIn.concat(textIn1);
					}//if end

					else {
						newUser = g[r];
						textIn2 = "You rolled a d" + (Obj2.dieChosen.length) + " and got a " + (Obj2.roll) + "\n";
						textIn = textIn.concat(textIn2);
						}//else end
				}//if end
				
			//card comparing
				else {
					if (r == 0) {
						newUser = g[r];
						textIn1 = "You drew a " + Obj.royals(n[r]) + " of " + Obj.getCardSuit() + "\n";
						textIn = textIn.concat(textIn1);
					}
					else {
						newUser = g[r];
						textIn2 = "You drew a " + Obj2.royals(n[r]) + " of " + Obj2.getCardSuit() + "\n";
						textIn = textIn.concat(textIn2);
					}
				}//else end
				
			}//for loop end
			
			//System.out.println("This is the max " + Obj.max  + " " + Obj2.max); this was used for testing purposes
			
		//running important method before code percentage calculations
			Obj2.getProbability();
			
		//comparing two dice
			if(Obj.max < 50 && Obj2.max < 50) {
				totalDice = (int)Obj.max + (int)Obj2.max;
				totalPoss = (int)Obj.max * (int)Obj2.max;
				totalRoll = Obj.roll + Obj2.roll;
				for(int o = 0; o < Obj.dieChosen.length; o++) {
					for (int p = 0; p < Obj2.dieChosen.length; p++) {
						if(totalRoll == Obj.dieChosen[o] + Obj2.dieChosen[p]) {
							times++;
						}
					}//Obj2 counting for loop end
				}//Obj counting for loop end
				textIn1 = String.format("The probability of the first object is %2.3f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.3f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				percentage = times / totalDice;
				textIn1 = "The max that can be rolled is " + (int)(Obj.max + Obj2.max) + "\n";
				textIn = textIn.concat(textIn1);
				
				textIn1 = "The total of " + totalRoll + " can be rolled " + (int)times + " times out of " + (int)totalPoss + " possible rolls\n";
				textIn = textIn.concat(textIn1);
							
				textIn1 = String.format((int)times + " divided by " + (int)totalPoss + " equals a %2.1f percent chance \n", ((times / totalPoss) * 100));
				textIn = textIn.concat(textIn1);
			}//if end
			
		//comparing two cards
			else if(Obj.max == 52 && Obj2.max == 51) {
				textIn1 = "The max number of cards that can be drawn is " + (int)(Obj.max) + "\n";
				textIn = textIn.concat(textIn1);
				
				textIn1 = String.format("The probability of the first object is %2.4f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.4f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				textIn1 = String.format("The total chance of drawing these cards is a %2.1f percent chance \n", (((2 / (Obj.max + Obj2.max)) * 100)));
				textIn = textIn.concat(textIn1);
			}
		
		//comparing a card and a die
			else if(Obj.max == 52 && Obj2.max < 50){
				textIn1 = "The max number of cards that can be drawn is " + (int)(Obj.max) + "\n";
				textIn2 = "The max that can be rolled is " + (int)(Obj2.max) + "\n";
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				textIn1 = String.format("The probability of the first object is %2.4f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.3f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);

				textIn1 = String.format("The total chance of drawing a card and rolling a die is %2.1f percent chance \n", (((2 / (Obj.max + Obj2.max)) * 100)));
				textIn = textIn.concat(textIn1);
			}
			
		//comparing a die and a card
			else {
				textIn1 = "The max that can be rolled is " + (int)(Obj.max) + "\n";
				textIn2 = "The max number of cards that can be drawn is " + (int)(Obj2.max) + "\n";
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				textIn1 = String.format("The probability of the first object is %2.3f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.4f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);

				textIn1 = String.format("The total chance of rolling a die and drawing a card is %2.1f percent chance \n", (((2 / (Obj.max + Obj2.max)) * 100)));
				textIn = textIn.concat(textIn1);
			}
			
		//final, display and input code
			textIn1 = "\nWould you like to compare two more objects?" + "\n";
			textIn2 = "Choose two more objects and click the calculate button" + "\n";
			textIn = textIn.concat(textIn1);
			textIn = textIn.concat(textIn2);
			
		//used for testing purposes to make sure nothing else is printed in the terminal
			System.out.println("Thank you for trying out my probability calculator.\n");
			

	//modified Old code end
			
			textFinal = textIn;
			
			setResults(Results, textFinal);
			
			
		//Grid code in calculate action
			//I will use a textArea to display the grid
			//look into multidimensional arrays to display a grid
			
			TextArea grid = new TextArea();
			grid.setWrapText(true);
			grid.setEditable(false);
			
			ScrollPane gridPane = new ScrollPane(grid);

			int gridLength;
			int gridHeight;
			int[][] matrix;
			
			if(input1 > input2) {
				gridLength = (int)Obj.max;
				gridHeight = (int)Obj2.max;	
				
			} //if end
			
			else if(input1 < input2) {
				gridLength = (int)Obj2.max;
				gridHeight = (int)Obj.max;

			} //else if end
			
			else {
				gridLength = (int)Obj.max;
				gridHeight = (int)Obj2.max;
			} //else end
			
			
			
			String gridLine = "\n";
			String gridSpace = "  ";
			String gridTexting = "";
			String gridText = "Here is all of the possible rolls\n";
			
			if(gridLength == 52 || gridHeight == 52) {
				gridText = "Please pick a dice object to show the grid probability pairings"
						+ "\nThe grid for cards is too big for this text area";
				setGrid(grid, gridText);
			}//if end
			
			else {
			
			matrix = new int[gridHeight][gridLength]; //initializing matrix

			//I got the matrix to print mostly how I would like it to be.
			//I would like the matrix to print out more of a graph that would look like the ruffle in a fabric
			
			for (int row = 0; row < matrix.length; row++) {
				for (int column = 0; column < matrix[row].length; column++) {
					gridTexting = String.format((row + 1) + "/" + (column + 1));
					gridText = gridText.concat(gridTexting);
					gridText = gridText.concat(gridSpace);
				}//for loop end
				
				gridText = gridText.concat(gridLine);
			}//for loop end
			
			gridText = gridText.concat(gridLine);
			gridText = gridText.concat(gridLine);
			
			
			
	//This is for displaying the graph
	
	/* I would have liked to have created the graph but I am out of time.
	 * 
	 * The graph would be created by using two arrays initialized as two
	 * separate arrays(using a for loop for each). The graph would be
	 * created by using a for loop that would be the 'number total' for the
	 * array indexes to add together to equal.(number total for loop with
	 * the first array index for loop nested under number total and the
	 * second array index for loop would be nested under the first array
	 * for loop). If both array indexes equal the number total then it
	 * would print out the pairing separated by a '/' and use "\n" outside
	 * of the if statement but within the second array for loop.
	 * 
	 * */
			
			} //else end
			
			setGrid(grid, gridText);
			
			gridPane.setLayoutX(0);
			gridPane.setLayoutY(362);
			
			pane.getChildren().add(gridPane);
			
			} //try end
			
			catch(NullPointerException ex) {
				textIn = "Please choose Probability Objects to compare\n";
				textFinal = textIn;
				setResults(Results, textFinal);
				throw ex;
			}//catch end
			
		});//calculate action end
		
		
		
	}//method start end

	private void setResults(TextArea Results, String textFinal) {
		Results.setText(textFinal);
	}//method setResults end
	
	private void setGrid(TextArea grid, String gridText) {
		grid.setText(gridText);
	}//method setGrid end
	
	

}//Class ProbabilityTest end
