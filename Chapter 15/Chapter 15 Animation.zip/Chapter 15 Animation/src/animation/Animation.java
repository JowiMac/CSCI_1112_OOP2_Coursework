/* John Macdonald, Nov 9 2022
 * 
 * This program animates a rectangle that
 * reduces its opacity as it moves along 
 * the outline of a polygon.
 * */

package animation;

import javafx.application.*;
import javafx.collections.ObservableList;
import javafx.animation.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Animation extends Application {
@Override
public void start(Stage primaryStage) throws Exception {
	primaryStage.setTitle("Animation and Opacity");
	
	Pane pane = new Pane();
	
	Polygon polygon = new Polygon();
	polygon.setFill(Color.WHITE);
	polygon.setStroke(Color.BLACK);
	
	
	double WIDTH = 230;
	double HEIGHT = 210;
	
	double centerX = WIDTH / 2;
	double centerY = HEIGHT / 2;
	double radius = Math.min(WIDTH, HEIGHT) * 0.4;
	
	ObservableList<Double> list = polygon.getPoints();
	for (int p = 0; p < 8; p++) {
		list.add(centerX + radius * Math.sin(2 * p * Math.PI / 8));
		list.add(centerY - radius * Math.cos(2 * p * Math.PI / 8));
	}
	
	Rectangle rectangle = new Rectangle( 0, 0, 30, 40);
	rectangle.setFill(Color.RED);
	
	pane.getChildren().add(polygon);
	pane.getChildren().add(rectangle);

	PathTransition t = new PathTransition();
	t.setPath(polygon);
	t.setNode(rectangle);
	t.setDuration(Duration.seconds(10));
	t.setCycleCount(Timeline.INDEFINITE);
	t.play();
	
	FadeTransition f = new FadeTransition(Duration.seconds(10), rectangle);
	f.setFromValue(1.0);
	f.setToValue(0.1);
	f.play();
	
	Scene scene = new Scene(pane, WIDTH, HEIGHT);
	
	polygon.setOnMousePressed(e -> {
		t.pause();
		f.pause();
	});
	
	polygon.setOnMouseReleased(e -> {
		t.play();
		f.play();
	});
	
		
	primaryStage.setScene(scene);
	primaryStage.show();

}//start method end

public static void main(String[] args) {
	Application.launch(args);
}//main method end

}//class Animation end
