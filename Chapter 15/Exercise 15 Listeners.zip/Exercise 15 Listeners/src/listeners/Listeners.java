/*John Macdonald, November 3, 2022
 * 
 * This code creates a circle that
 * moves in a new window by using
 * the in-window buttons.
 * */

package listeners;

import javafx.application.Application; //Every javafx program extends Application
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.event.*;
import javafx.scene.paint.Color;


public class Listeners extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		primaryStage.setTitle("Listeners");
		
		Button bt1 = new Button("Up");
		Button bt2 = new Button("Down");
		Button bt3 = new Button("Left");
		Button bt4 = new Button("Right");
		
		BorderPane borderPane = new BorderPane();
		
		Pane pane = new Pane();
		
		Circle circle = new Circle(50);
		circle.setCenterX(150);
		circle.setCenterY(125);
		circle.setStroke(Color.BLACK);
		circle.setFill(Color.WHITE);
		
		pane.getChildren().add(circle);

		HBox hBox = new HBox(10);
		
		borderPane.setCenter(pane);
		
		borderPane.setBottom(hBox);
		
				
		hBox.getChildren().addAll(bt1, bt2, bt3, bt4);
		
		
		System.out.println("This is the x coordinate " + circle.getCenterX());
		System.out.println("This is the y coordinate " + circle.getCenterY());
		
		System.out.println("This is the Radius " + circle.getRadius());
				
		Scene scene = new Scene(borderPane, 300, 250);

		
		bt1.setOnAction(e -> {
			if(circle.getCenterY() < 51) {
				circle.setCenterY(50);
			}
			else {
				circle.setCenterY(circle.getCenterY() - 25);
			}
			
		});
		
		bt2.setOnAction(e -> {
			if(circle.getCenterY() > 199) {
				circle.setCenterY(200);
			}
			else {
			circle.setCenterY(circle.getCenterY() + 25);
			}
		});
		
		bt3.setOnAction(e -> {
			if(circle.getCenterX() < 51) {
				circle.setCenterX(50);
			}
			else {
			circle.setCenterX(circle.getCenterX() - 25);
			}
		});
		
		bt4.setOnAction(e -> {
			if(circle.getCenterX() > 249) {
				circle.setCenterX(250);
			}
			else {
			circle.setCenterX(circle.getCenterX() + 25);
			}
		});
		
		
		primaryStage.setScene(scene);
		primaryStage.show();
	
		
	}//Start method end


public static void main(String[] args) {
	Application.launch(args);
}

}//Listeners class end

